from collections import namedtuple

TAMANNO_LETRA = 20
FPS_inicial = 3
TIEMPO_MAX = 61

ANCHO = 800
ALTO = 600
COLOR_LETRAS = (20,200,20)
COLOR_FONDO = (0,0,0)
COLOR_TEXTO = (200,200,200)
COLOR_TIEMPO_FINAL = (200,20,10)
Punto = namedtuple('Punto','x y')



